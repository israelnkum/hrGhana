@include('includes.header')
@include('includes.navs')
@yield('content')
@include('includes.footer')