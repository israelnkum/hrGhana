<?php $__env->startSection('content'); ?>


    <section class="slider-section">
        <div class="slider-wrapper">
            <div id="main-slider" class="nivoSlider">
                <img src="<?php echo e(assets('img/slider-1.jpg')); ?>" alt="" title="#slider-caption-1"/>
                <img src="<?php echo e(assets('img/slider-2.jpg')); ?>" alt="" title="#slider-caption-2"/>
                <img src="<?php echo e(assets('img/slider-3.jpg')); ?>" alt="" title="#slider-caption-3"/>
            </div><!-- /#main-slider -->

            <div id="slider-caption-1" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                
                                <h1 class="wow cssanimation leFadeInRight sequence display-4">Better Life for People</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /#slider-caption-1 -->
            <div id="slider-caption-2" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                <h1 class="wow cssanimation fadeInTop" data-wow-delay="1s" data-wow-duration="800ms">Together we  <br>can make a Difference</h1>
                                <p class="wow cssanimation fadeInBottom" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /#slider-caption-2 -->
            <div id="slider-caption-3" class="nivo-html-caption slider-caption">
                <div class="display-table">
                    <div class="table-cell">
                        <div class="container">
                            <div class="slider-text">
                                
                                <h1 class="wow cssanimation lePushReleaseFrom sequence" data-wow-delay="1s">Give a little. Change a lot.</h1>
                                <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /#slider-caption-3 -->
        </div>
    </section><!-- /#slider-Section -->

    <section class="promo-section bd-bottom">
        <div class="promo-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 xs-padding">
                        <div class="profile-wrap">
                            <img class="profile" src="public/img/profile.jpg" alt="profile">
                            <h3>Ernestina Baaba Allotey <span>CEO & Founder of HR Ghana.</span></h3>
                            
                        </div>
                    </div>

                    <div class="col-md-4 xs-padding">
                        <div class="profile-wrap">
                            <h2>Our Vision</h2>
                            <p>
                                Changing an orphan’s future through the love of God and family.
                            </p>
                            <a href="/about-us" class="default-btn btn-sm">Read More</a>
                        </div>
                    </div>

                    <div class="col-md-4 xs-padding">
                        <div class="profile-wrap">
                            <h2>Our Mission</h2>
                            <p>
                                Providing loving, nurturing, Christ-centered homes for orphaned Children.
                            </p>
                            <a href="/about-us" class="default-btn btn-sm">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /Promo Section -->


    <section class="events-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="section-heading text-center mb-40">
                <h2>Upcoming Events</h2>
                <span class="heading-border"></span>
                
            </div><!-- /Section Heading -->
            <div id="event-carousel" class="events-wrap owl-Carousel">
                <div class="events-item">
                    <div class="event-thumb">
                        <img src="public/img/events-1.jpg" alt="events">
                    </div>
                    <div class="event-details">
                        <h3>Let's talk about the poor children education.</h3>
                        <div class="event-info">
                            
                            
                        </div>
                        <p>
                            Its aim was to develop positive school cultures on the basis of the rights of the child and to improve achievement for all children through having schools and early childhood education centers become learning communities that know, promote, and live human rights and responsibilities.
                        </p>
                        
                    </div>
                </div><!-- Event-1 -->
                <div class="events-item">
                    <div class="event-thumb">
                        <img src="public/img/events-2.jpg" alt="events">
                    </div>
                    <div class="event-details">
                        <h3>Insure clean water to everyone in Africa.</h3>
                        <div class="event-info">
                            
                            
                        </div>
                        <p>
                            Ensuring universal access to safe and affordable drinking water for all by 2030 requires we invest in adequate infrastructure, provide sanitation facilities and encourage hygiene at every level. Protecting and restoring water-related ecosystems such as forests, mountains, wetlands and rivers is essential if we are to mitigate water scarcity.
                        </p>
                        
                    </div>
                </div><!-- Event-2 -->

            </div>
        </div>
    </section><!-- Events Section -->











    <section id="counter" class="counter-section">
        <div class="container">
            <ul class="row counters">
                <li class="col-md-3 col-sm-6 sm-padding">
                    <div class="counter-content">
                        <i class="ti-money"></i>
                        <h3 class="counter">85389</h3>
                        <h4 class="text-white">Money Donated</h4>
                    </div>
                </li>
                <li class="col-md-3 col-sm-6 sm-padding">
                    <div class="counter-content">
                        <i class="ti-face-smile"></i>
                        <h3 class="counter">10693</h3>
                        <h4 class="text-white">Volunteer Around The World</h4>
                    </div>
                </li>
                <li class="col-md-3 col-sm-6 sm-padding">
                    <div class="counter-content">
                        <i class="ti-user"></i>
                        <h3 class="counter">50177</h3>
                        <h4 class="text-white">People Impacted</h4>
                    </div>
                </li>
                <li class="col-md-3 col-sm-6 sm-padding">
                    <div class="counter-content">
                        <i class="ti-comments"></i>
                        <h3 class="counter">669</h3>
                        <h4 class="text-white">Positive Feedbacks</h4>
                    </div>
                </li>
            </ul>
        </div>
    </section><!-- Counter Section -->



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>